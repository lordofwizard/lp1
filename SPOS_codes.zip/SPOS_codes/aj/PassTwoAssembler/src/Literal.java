
public class Literal {
	private String name;
	private int address;
	
	public Literal(String name, int address) {
		this.name = name;
		this.address = address;
	}
	
	public int getAddress() {
		return address;
	}
	
	public String getName() {
		return name;
	}
	
}
