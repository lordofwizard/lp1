package rohitsuthar.others;

public class Msg {
	public static <T> void print(T t) {
		System.out.print(t);
	}
	
	public static <T> void println(T t) {
		System.out.println(t);
	}
}
